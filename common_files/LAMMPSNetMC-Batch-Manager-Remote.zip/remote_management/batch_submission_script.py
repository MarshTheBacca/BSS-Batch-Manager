import argparse
import getpass
import logging
import os
import shutil
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path
from zipfile import BadZipFile, ZipFile


class EmptyBatchError(Exception):
    pass


def command_lines(command_array: str) -> list[str]:
    """
    Executes a command on the remote server and returns the output as a list of lines

    Args:
        command_array: The command to be executed
    Returns:
        A list of the lines of the output
    """
    lines = subprocess.run(command_array, stdout=subprocess.PIPE, shell=True).stdout.decode("utf-8").split("\n")[:-1]
    return lines


def find_char_indexes(string: str, target_char: str, invert: bool = False) -> list[int]:
    """
    Finds the indexes of all occurrences of the target character in the string
    Args:
        string: The string to be searched
        target_char: The character to be found
        invert: Whether or not to invert the search
    Returns:
        A list of the indexes of the target character in the string
    """
    return [i for i, char in enumerate(string) if (char == target_char) is not invert]


def job_script_maker(template_file_path: Path,
                     save_path: Path,
                     exec_name: str,
                     job_desc: str = "qsub_log") -> None:
    """
    Creates a job submission script from a template file with the correct paths, job description and executable name

    Args:
        template_file_path: The path to the template file
        save_path: The path to save the new job submission script
        exec_name: The name of the executable to be run
        job_desc: The description of the job
    """
    JOB_DESC_LINE = 7
    JOB_PATH_LINE = 9
    EXEC_LINE = 15

    with template_file_path.open("r") as template_file:
        template_lines = template_file.readlines()

    template_lines[JOB_DESC_LINE - 1] = f"#$ -N {job_desc}\n"
    template_lines[JOB_PATH_LINE - 1] = f'job_dir="{save_path.parent}"\n'
    template_lines[EXEC_LINE - 1] = f"./{exec_name}\n"

    with save_path.open("w+") as new_template_file:
        new_template_file.writelines(template_lines)


def import_qstat(username: str) -> list[tuple[str, str, datetime]]:
    """
    Gets the job id, job name and start time of all jobs in qstat for a given username

    Args:
        username: The username to search for in qstat
    Returns:
        A list of tuples containing the job id, job name and start time
    """
    # qstat has a lot of information, but we only need the job id, job name and start time
    # Every job listed in qstat has a job-ID line in this format:
    #     0        1         2      3      4          5            6
    # [job-ID] [priority] [name] [user] [state] [submit-date] [submit-time] ... and others
    # The next line is intended like so:         Full jobname: [job-name]
    # To extract this information, we take every line that starts with a digit (job-id) or starts with "Full jobname"
    lines = (line for line in command_lines(f"qstat -u {username} -r") if line[0].isdigit() or line.strip().startswith("Full jobname"))
    jobs = []
    for i, line in enumerate(lines):
        if i % 2 == 0:
            # The job-ID line
            job_data = line.split()
            job_id = job_data[0]
            start_date = datetime.strptime(job_data[5], "%m/%d/%Y").date()
            start_time = datetime.strptime(job_data[6], "%H:%M:%S").time()
        else:
            # The job-name line
            job_name = line.split()[2]
            start = datetime.combine(start_date, start_time, tzinfo=timezone.utc)
            jobs.append((job_id, job_name, start))
    return jobs


def get_files(path: Path) -> list[Path]:
    """
    Gets all the paths inside a path that are files recursively

    Args:
        path: The path to search for files in
    Returns:
        A list of all the paths that are files inside the given path
    """
    return [file for file in Path(path).rglob('*') if file.is_file()]


def submit_batch(username: str, exec_name: str, run_path: Path, batch_desc: str) -> None:
    """
    Submits a batch of jobs using qsub

    Args:
        username: The username of the user submitting the jobs
        exec_name: The name of the executable to be run
        run_path: The path to the batch of jobs
        batch_desc: The description of the batch

    Raises:
        EmptyBatchError: If there are no jobs in the batch
    """
    cwd = Path(__file__).parent.resolve()
    job_script_template_path = cwd.joinpath("job_submission_template.sh")
    batch_job_names = [job.name for job in Path.iterdir(run_path) if job.is_dir()]
    if not batch_job_names:
        raise EmptyBatchError("No jobs found in batch")
    # Submit each job in the batch
    for job_name in batch_job_names:
        job_path = run_path.joinpath(job_name)
        job_script_path = job_path.joinpath("job_submission_script.sh")

        # Copy over the the execuatable to the job path
        shutil.copy(cwd.joinpath(exec_name), job_path.joinpath(exec_name))

        # Make sure the output_files path exists, otherwise job doesn't output any files despite running
        Path.mkdir(job_path.joinpath("output_files"), exist_ok=True)

        # Generate unique job_submission_script.sh for the job that has the correct path for qsub inside
        job_script_maker(job_script_template_path,
                         job_script_path,
                         exec_name, batch_desc)

        # Start a loop to submit each job
        while True:
            num_jobs = len(command_lines(f'qstat | grep "{username}"'))

            # if there are more than 200 jobs in our qstat, then wait 5 seconds
            if num_jobs < 201:
                break
            time.sleep(5)

        # Once there are <201 jobs in parallel, submit the job and start the next iteration.
        command_lines(f"qsub -j y -o {job_path} {job_path.joinpath('job_submission_script.sh')}")


def wait_for_completion(username: str, batch_desc: str) -> None:
    """
    Waits for all jobs in a batch to finish, or until a timeout is reached (5 months)

    Args:
        username: The username of the user who submitted the jobs
        batch_desc: The description of the batch
    """
    # 5 months is approximately 5*30*24*60*60 = 10,800,000 seconds
    timeout = 5 * 30 * 24 * 60 * 60
    start_time = time.time()

    # Now wait until there are no jobs in qstat with our batch_desc defined above, checking every 5 seconds
    while True:
        elapsed_time = time.time() - start_time
        if elapsed_time > timeout:
            print("Timeout reached, exiting")
            break
        job_names: list[str] = [job[1] for job in import_qstat(username)]
        if batch_desc not in job_names:
            break
        time.sleep(5)


def create_zip(run_path: Path, exec_name: str) -> None:
    """
    Creates a zip file of the run folder, excluding the executable and the job submission script

    Args:
        run_path: The path to the run folder
        exec_name: The name of the executable
    """
    paths_to_write: list[Path] = []
    failed_job_names: list[str] = []
    excluded_files: set = {"job_submission_script.sh", exec_name}

    # Get all the files that are 1) A file, 2) Not empty 3) Not in excluded files
    for file in run_path.rglob('*'):
        if file.is_file() and file.stat().st_size != 0 and file.name not in excluded_files:
            paths_to_write.append(file)
            if "core." in file.name:
                # Files called 'core.XXXX' means the C++ executable crashed somehow
                failed_job_names.append(file.parent.relative_to(run_path))

    return_zip_path = run_path.with_suffix('.zip')

    with ZipFile(return_zip_path, "x") as return_zip:
        for path in paths_to_write:
            relative_path = path.relative_to(run_path)
            if relative_path.parent in failed_job_names:
                return_zip.write(path, Path("failed_jobs").joinpath(relative_path))
                continue
            return_zip.write(path, relative_path)


def main() -> None:
    parser = argparse.ArgumentParser(description="Submit jobs without overloading Coulson")
    parser.add_argument("-p", type=str, help="Path to run folder", metavar="path", required=True)
    args = parser.parse_args()

    run_path: Path = Path(args.p).resolve()
    log_path: Path = run_path.joinpath("batch_submission_script.log")

    # Clear the log
    log_path.open('w').close()
    logging.basicConfig(filename=log_path,
                        format="[%(asctime)s] [%(levelname)s]: %(message)s",
                        datefmt="%Y-%m-%d %H:%M:%S",
                        level=logging.INFO)

    logging.info("Starting batch submission script")
    logging.info("Initialising variables")
    if not os.access(run_path.parent, os.W_OK):
        logging.error(f"You don't have permission to write to {run_path.parent}")
        return

    exec_name: str = "coulson_lammps_netmc.x"
    batch_desc: str = run_path.name
    username: str = getpass.getuser()

    logging.info("Unzipping batch")
    # Unzip the batch zip sent over from remote host, and delete it
    try:
        zip_path: Path = next(file for file in Path(run_path).iterdir() if file.suffix == '.zip')
        with ZipFile(zip_path, 'r') as batch_zip:
            batch_zip.extractall(run_path)
        zip_path.unlink()
    except StopIteration:
        logging.error(f"No zip file found in {run_path}")
        return
    except BadZipFile:
        logging.error(f"Bad zip file {zip_path}")
        return

    # Submit the batch using qsub (maximum of 200 jobs at a time)
    logging.info("Submitting batch")
    try:
        submit_batch(username, exec_name, run_path, batch_desc)
    except EmptyBatchError:
        logging.error("No jobs found in batch")
        return
    except Exception as e:
        logging.error(f"Error submitting batch: {e}")
        return

    # Wait for the batch to finish
    logging.info("Waiting for completion")
    try:
        wait_for_completion(username, batch_desc)
    except Exception as e:
        logging.error(f"Error waiting for completion: {e}")
        return

    # Zip up the finished batch
    logging.info("Creating zip file of run folder")
    try:
        create_zip(run_path, exec_name)
        # Delete run folder
        shutil.rmtree(run_path)
    except Exception as e:
        logging.error(f"Error creating zip and deleting run folder: {e}")
        return
    logging.info("Batch submission script finished")


if __name__ == "__main__":
    main()
