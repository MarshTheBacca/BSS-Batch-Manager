import os
import argparse
import subprocess
from zipfile import ZipFile
from time import sleep
from shutil import unpack_archive, copytree, copy, rmtree
from linecache import getline
from datetime import datetime, timezone


def command_lines(command_array):
    lines = subprocess.run(command_array, stdout = subprocess.PIPE, shell = True).stdout.decode("utf-8").split("\n")[:-1]
    return lines

def find_char_indexes(string, target_char, invert = 0):
    matching_indexes = []
    for i, char in enumerate(string):
        if char == target_char and invert == 0:
            matching_indexes.append(i)
        elif char != target_char and invert == 1:
            matching_indexes.append(i)
    return matching_indexes

def get_seed(inpt_file_path, cwd):
    seeds_path = os.path.join(cwd, "triangle_raft_seeds")
    job_path = os.path.dirname(inpt_file_path)
    string = getline(inpt_file_path, 2)
    seed = string[find_char_indexes(string, "/")[-1] + 1:find_char_indexes(string, " ")[0]]
    existing_seeds = [seed for seed in os.scandir(seeds_path) if seed.is_dir()]
    for existing_seed in existing_seeds:
        if seed == existing_seed.name:
            copytree(existing_seed.path, os.path.join(job_path, "seed"))
            return
    os.chdir(job_path)
    os.system("python3 {os.path.join(seeds_path, 'make_poly_seed.py')} {seed}")
    os.chdir(cwd)
    copytree(os.path.join(seeds_path, seed), os.path.join(job_path, "seed"))
    
def job_script_maker(template_file_path,
                     save_path,
                     exec_name,
                     job_desc = "qsub_log",
                     job_path_line = 9,
                     exec_line = 15):
    
    with open(template_file_path, "r") as file:
        template_lines = file.read().split("\n")
        
    template_lines[6] = f"#$ -N {job_desc}"
    template_lines[job_path_line-1] = f'job_dir="{os.path.dirname(save_path)}"'
    template_lines[exec_line - 1] = f"./{exec_name}"
    
    with open(os.path.join(save_path), "w+") as file:
        for line in template_lines:
            file.write(f"{line}\n")

def import_qstat(raw_lines):
    lines = [] 
    for line in raw_lines:
        if line:
            if line[0] != " ":
                lines.append(line)
            elif line.strip()[0] == "F":
                lines.append(line)
    del lines[0:2]
    jobs = []
    for i in range(0,len(lines),2):
        select_1 = lines[i].split()
        select_2 = lines[i+1].split()
        job_id = select_1[0]
        job_name = select_2[2]
        start_date = select_1[5]
        start_time = select_1[6]
        start_date_time = start_date + " " + start_time
        start = datetime.strptime(start_date_time, "%m/%d/%Y %H:%M:%S").replace(tzinfo=timezone.utc)
        jobs.append([job_id, job_name, start])
    return jobs

def get_files(path):
    sub_folders = get_folders(path)
    files = []
    for sub_folder in sub_folders:
        files.extend([file for file in os.scandir(sub_folder) if file.is_file()])
    return files

def get_folders(path):
    sub_folders = [file for file in os.scandir(path) if file.is_dir()]
    for sub_folder in sub_folders:
        sub_folders.extend(get_folders(sub_folder.path))
    return sub_folders

#Get options using argparse and define current working directory and local username
parser = argparse.ArgumentParser(description = "Submit jobs without overloading Coulson")
parser.add_argument("-p", type = str, help = "Path to run folder", metavar = "path", required = True)
parser.add_argument("-t", type = str, help = "Program type, NetMC/Triangle Raft", metavar = "prog_type", required = True)
args = parser.parse_args()

run_path = os.path.realpath(args.p)
batch_name = os.path.basename(os.path.dirname(run_path))
prog_type = args.t

cwd = os.path.realpath(os.path.dirname(__file__))

exec_names = {"netmc": "netmc.x", "triangle_raft": "mx2.x"}
inpt_names = {"netmc": "netmc.inpt", "triangle_raft": "mx2.inpt"}
exec_name = exec_names[prog_type]
inpt_name = inpt_names[prog_type]
exec_path = os.path.join(cwd, f"coulson_{exec_name}")
job_script_template_path = os.path.join(cwd, "job_submission_template.sh")

username = os.getlogin()

#Unzip the batch zip sent over from remote host, and delete it
zip_path = next(os.scandir(run_path)).path
unpack_archive(zip_path, run_path, "zip")
os.remove(zip_path)

#batch_desc appears on qstat -u {username} -r (-r means the full name is displayed, useful later on)
batch_desc = os.path.basename(run_path)
batch_job_names=[job.name for job in os.scandir(run_path) if job.is_dir()]

#Submit each job in the batch
for job_name in batch_job_names:
    job_path = os.path.join(run_path, job_name)
    
    #Copy over the relevant netmc.x or mx2.x to the job path
    copy(exec_path, os.path.join(job_path, exec_name))

    #Make sure the output_files path exists, otherwise job doesn't output any files despite running
    os.mkdir(os.path.join(job_path, "output_files"))

    #Generate unique job_submission_script.sh for the job that has the correct path for qsub inside
    job_script_maker(job_script_template_path, os.path.join(job_path, "job_submission_script.sh"), exec_name, batch_desc)

    #Add the seed to job path if type is triangle_raft
    if prog_type == "triangle_raft":
        get_seed(os.path.join(job_path, inpt_name), cwd)

    #Start a loop to submit each job
    while True:
        qstat_length = len(command_lines([f'qstat | grep "{username}"']))
        
        #if there are more than 100 jobs in our qstat, then wait 5 seconds
        if qstat_length < 101:
            break
        sleep(5)

    #Once there are <101 jobs in parallel, submit the job and start the next iteration.
    command_lines(f"qsub -j y -o {job_path} {os.path.join(job_path, 'job_submission_script.sh')}")

#Now wait until there are no jobs in qstat with out batch_desc defined above, checking every 5 seconds
while True:
    qstat_lines = command_lines(f"qstat -u {username} -r")
    jobs = import_qstat(qstat_lines)
    job_names = [job[1] for job in jobs]
    if batch_desc not in job_names:
        break
    sleep(5)

#Get all the paths we want to write to our output zip file
paths_to_write, failed_job_names   = [], []
excluded_files = ("job_submission_script.sh", exec_name)
for file in get_files(run_path):
    if file.is_file:
        #We don't want to send over our seed again, as this is not relevant to the analysis later
        #Also exclude any empty files and anything listed in exluded_files (the c++ script and unique job_script)
        if os.stat(file.path).st_size != 0 and ("seed" not in os.path.normpath(file.path).split(os.sep)) and file.name not in excluded_files:
            paths_to_write.append(file.path)
        #Any job folder with a core.xxxxx file means the C++ executable crashed
        if "core." in file.name:
            failed_job_names.append(os.path.dirname(os.path.relpath(file.path, run_path)))
return_zip_path = f"{run_path}.zip"
#Zip up all our paths
with ZipFile(return_zip_path, "x") as return_zip:
    for path in paths_to_write:
        #Be sure to use relative paths to the run path!
        relative_path = os.path.relpath(os.path.realpath(path), run_path)
        
        #Put all the failed jobs in a folder called 'failed_jobs' in the zip
        if os.path.relpath(os.path.realpath(path), run_path).split(os.sep)[0] in failed_job_names:
            return_zip.write(path, os.path.join("failed_jobs", relative_path))
            
        else:
            return_zip.write(path, relative_path)
            
#Delete original run folder
rmtree(run_path)
